const express = require("express");
const db = require("../db/store");
const { requireAdminAuth } = require("../middleware/adminAuth");

const router = express.Router();

router.use(requireAdminAuth);

/**
 * GET /api/admin/progress
 * يرجع تقدّم كل مفتاح تصريح (كم درس أكمل، آخر نشاط)
 */
router.get("/", (req, res) => {
  const allProgress = db.getAll("progress");
  const keys = db.getAll("keys");
  const lessons = db.getAll("lessons");

  const summary = keys.map((key) => {
    const entries = allProgress.filter((p) => p.keyValue === key.keyValue);
    const lastActivity = entries
      .map((e) => e.completedAt)
      .sort()
      .reverse()[0];

    return {
      keyValue: key.keyValue,
      note: key.note,
      totalLessons: lessons.length,
      completedLessons: entries.length,
      completionPercent: lessons.length
        ? Math.round((entries.length / lessons.length) * 100)
        : 0,
      lastActivity: lastActivity || null,
    };
  });

  res.json({ summary });
});

module.exports = router;
