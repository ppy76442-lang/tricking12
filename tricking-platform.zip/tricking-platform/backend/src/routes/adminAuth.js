const express = require("express");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const db = require("../db/store");

const router = express.Router();

function hashPassword(password) {
  const salt = process.env.PASSWORD_SALT || "tricking-default-salt-change-me";
  return crypto.createHash("sha256").update(password + salt).digest("hex");
}

/**
 * POST /api/admin/login
 * body: { username, password }
 */
router.post("/login", (req, res) => {
  const { username, password } = req.body || {};

  if (!username || !password) {
    return res.status(400).json({ error: "اسم المستخدم وكلمة المرور مطلوبان." });
  }

  const admin = db.findOne("admins", (a) => a.username === username);

  if (!admin || admin.passwordHash !== hashPassword(password)) {
    return res.status(401).json({ error: "اسم المستخدم أو كلمة المرور غير صحيحة." });
  }

  const secret = process.env.JWT_SECRET || "dev-secret-change-me-in-production";
  const token = jwt.sign(
    { sub: admin.id, username: admin.username, role: "admin" },
    secret,
    { expiresIn: "12h" }
  );

  res.json({ token, username: admin.username });
});

module.exports = router;
