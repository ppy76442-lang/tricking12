const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../db/store");
const { requireAdminAuth } = require("../middleware/adminAuth");

const router = express.Router();

router.use(requireAdminAuth);

/** GET /api/admin/lessons */
router.get("/", (req, res) => {
  const lessons = db.getAll("lessons").sort((a, b) => a.order - b.order);
  res.json({ lessons });
});

/**
 * POST /api/admin/lessons
 * body: { title, level, description, order?, exercises: [{name, dose, videoUrl}] }
 */
router.post("/", async (req, res) => {
  const { title, level = "", description = "", order, exercises = [] } = req.body || {};

  if (!title) {
    return res.status(400).json({ error: "عنوان الدرس مطلوب." });
  }

  const existing = db.getAll("lessons");
  const newOrder = order !== undefined ? Number(order) : existing.length + 1;

  const lesson = await db.insert("lessons", {
    id: uuidv4(),
    title,
    level,
    description,
    order: newOrder,
    exercises,
    createdAt: new Date().toISOString(),
  });

  res.status(201).json({ lesson });
});

/** PATCH /api/admin/lessons/:id */
router.patch("/:id", async (req, res) => {
  const { title, level, description, order, exercises } = req.body || {};
  const updates = {};
  if (title) updates.title = title;
  if (level !== undefined) updates.level = level;
  if (description !== undefined) updates.description = description;
  if (order !== undefined) updates.order = Number(order);
  if (exercises) updates.exercises = exercises;

  const updated = await db.updateById("lessons", req.params.id, updates);
  if (!updated) return res.status(404).json({ error: "الدرس غير موجود." });

  res.json({ lesson: updated });
});

/** DELETE /api/admin/lessons/:id */
router.delete("/:id", async (req, res) => {
  const deleted = await db.deleteById("lessons", req.params.id);
  if (!deleted) return res.status(404).json({ error: "الدرس غير موجود." });
  res.json({ success: true });
});

module.exports = router;
