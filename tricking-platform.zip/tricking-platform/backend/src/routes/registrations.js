const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../db/store");

const router = express.Router();

const WHATSAPP_NUMBER = process.env.WHATSAPP_NUMBER || "776724399";

/**
 * POST /api/registrations
 * body: { fullName, age, country, phone }
 *
 * يحفظ الطلب في قاعدة البيانات للمراجعة من لوحة التحكم،
 * ويرجع رابط واتساب جاهز يفتحه الـ frontend مباشرة في تبويب جديد.
 */
router.post("/", async (req, res) => {
  const { fullName, age, country, phone } = req.body || {};

  if (!fullName || !age || !country || !phone) {
    return res.status(400).json({ error: "جميع الحقول مطلوبة: الاسم، العمر، الدولة، الهاتف." });
  }

  const ageNum = Number(age);
  if (!Number.isFinite(ageNum) || ageNum < 5 || ageNum > 100) {
    return res.status(400).json({ error: "العمر يجب أن يكون رقمًا منطقيًا." });
  }

  const registration = await db.insert("registrations", {
    id: uuidv4(),
    fullName: String(fullName).trim(),
    age: ageNum,
    country: String(country).trim(),
    phone: String(phone).trim(),
    status: "pending",
    createdAt: new Date().toISOString(),
  });

  const message = encodeURIComponent(
    `طلب انضمام جديد لبرنامج التريكنغ:\n` +
      `الاسم: ${registration.fullName}\n` +
      `العمر: ${registration.age}\n` +
      `الدولة: ${registration.country}\n` +
      `الهاتف: ${registration.phone}`
  );

  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${message}`;

  res.status(201).json({ registration, whatsappUrl });
});

module.exports = router;
