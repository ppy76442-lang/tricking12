const express = require("express");
const db = require("../db/store");

const router = express.Router();

/**
 * GET /api/videos
 * يرجع الفيديوهات النشطة فقط، مرتبة للعرض في الصفحة الرئيسية.
 * هذا المسار عام (لا يتطلب مفتاح تصريح) لأن الفيديوهات الاستعراضية
 * هي ما يشاهده الزائر قبل التسجيل لتشجيعه على الانضمام.
 */
router.get("/", (req, res) => {
  const videos = db
    .getAll("videos")
    .filter((v) => v.active)
    .sort((a, b) => a.order - b.order)
    .map(({ id, platform, url, title, orientation }) => ({
      id,
      platform,
      url,
      title,
      orientation,
    }));

  res.json({ videos });
});

module.exports = router;
