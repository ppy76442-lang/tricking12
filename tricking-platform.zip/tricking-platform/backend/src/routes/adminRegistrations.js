const express = require("express");
const db = require("../db/store");
const { requireAdminAuth } = require("../middleware/adminAuth");

const router = express.Router();

router.use(requireAdminAuth);

/** GET /api/admin/registrations — كل طلبات التسجيل، الأحدث أولاً */
router.get("/", (req, res) => {
  const regs = db
    .getAll("registrations")
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json({ registrations: regs });
});

/**
 * PATCH /api/admin/registrations/:id — تحديث حالة الطلب
 * body: { status: "pending" | "contacted" | "approved" | "rejected" }
 */
router.patch("/:id", async (req, res) => {
  const { status } = req.body || {};
  const allowed = ["pending", "contacted", "approved", "rejected"];
  if (!status || !allowed.includes(status)) {
    return res.status(400).json({ error: `الحالة يجب أن تكون أحد: ${allowed.join(", ")}` });
  }

  const updated = await db.updateById("registrations", req.params.id, { status });
  if (!updated) return res.status(404).json({ error: "الطلب غير موجود." });

  res.json({ registration: updated });
});

/** DELETE /api/admin/registrations/:id */
router.delete("/:id", async (req, res) => {
  const deleted = await db.deleteById("registrations", req.params.id);
  if (!deleted) return res.status(404).json({ error: "الطلب غير موجود." });
  res.json({ success: true });
});

module.exports = router;
