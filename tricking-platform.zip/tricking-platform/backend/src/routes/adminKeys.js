const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../db/store");
const { requireAdminAuth } = require("../middleware/adminAuth");
const { isExpired } = require("../middleware/keyAuth");

const router = express.Router();

// كل المسارات هنا تتطلب تسجيل دخول أدمن
router.use(requireAdminAuth);

/** يولّد مفتاح تصريح عشوائي مكوّن من أرقام (شبيه بالمثال: 500485896) */
function generateKeyValue() {
  return String(Math.floor(100000000 + Math.random() * 899999999));
}

/** GET /api/admin/keys — كل المفاتيح مع حالتها الفعلية (منتهي/فعّال) */
router.get("/", (req, res) => {
  const keys = db.getAll("keys").map((k) => ({
    ...k,
    effectiveStatus: k.status === "disabled" ? "disabled" : isExpired(k) ? "expired" : "active",
  }));
  res.json({ keys });
});

/**
 * POST /api/admin/keys — إنشاء مفتاح جديد
 * body: { durationDays?: number, note?: string, customKey?: string }
 */
router.post("/", async (req, res) => {
  const { durationDays = 30, note = "", customKey } = req.body || {};

  if (customKey) {
    const exists = db.findOne("keys", (k) => k.keyValue === customKey);
    if (exists) {
      return res.status(409).json({ error: "هذا المفتاح موجود مسبقًا، اختر قيمة أخرى." });
    }
  }

  const keyValue = customKey || generateKeyValue();

  const newKey = await db.insert("keys", {
    id: uuidv4(),
    keyValue,
    status: "active",
    durationDays: Number(durationDays) || 30,
    createdAt: new Date().toISOString(),
    activatedAt: null,
    note,
  });

  res.status(201).json({ key: newKey });
});

/**
 * PATCH /api/admin/keys/:id — تعديل حالة مفتاح (تعطيل/تفعيل) أو مدته
 * body: { status?: "active"|"disabled", durationDays?: number, note?: string }
 */
router.patch("/:id", async (req, res) => {
  const { status, durationDays, note } = req.body || {};
  const updates = {};
  if (status && ["active", "disabled"].includes(status)) updates.status = status;
  if (durationDays !== undefined) updates.durationDays = Number(durationDays);
  if (note !== undefined) updates.note = note;

  const updated = await db.updateById("keys", req.params.id, updates);
  if (!updated) return res.status(404).json({ error: "المفتاح غير موجود." });

  res.json({ key: updated });
});

/** DELETE /api/admin/keys/:id — حذف مفتاح نهائيًا */
router.delete("/:id", async (req, res) => {
  const deleted = await db.deleteById("keys", req.params.id);
  if (!deleted) return res.status(404).json({ error: "المفتاح غير موجود." });
  res.json({ success: true });
});

module.exports = router;
