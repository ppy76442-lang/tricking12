const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../db/store");
const { requireValidKey } = require("../middleware/keyAuth");

const router = express.Router();

// كل المسارات هنا تتطلب مفتاح تصريح صالح في الهيدر x-access-key
router.use(requireValidKey);

/** GET /api/lessons — كل الدروس مع إشارة لما أنجزه هذا المفتاح */
router.get("/", (req, res) => {
  const lessons = db.getAll("lessons").sort((a, b) => a.order - b.order);
  const myProgress = db.findMany("progress", (p) => p.keyValue === req.keyRecord.keyValue);
  const completedIds = new Set(myProgress.map((p) => p.lessonId));

  const result = lessons.map((lesson) => ({
    ...lesson,
    completed: completedIds.has(lesson.id),
  }));

  res.json({ lessons: result });
});

/**
 * POST /api/lessons/:id/complete
 * يسجّل إنجاز هذا الدرس لهذا المفتاح (إن لم يكن مسجلًا من قبل)
 */
router.post("/:id/complete", async (req, res) => {
  const lesson = db.findOne("lessons", (l) => l.id === req.params.id);
  if (!lesson) return res.status(404).json({ error: "الدرس غير موجود." });

  const already = db.findOne(
    "progress",
    (p) => p.keyValue === req.keyRecord.keyValue && p.lessonId === lesson.id
  );

  if (already) {
    return res.json({ progress: already, alreadyCompleted: true });
  }

  const entry = await db.insert("progress", {
    id: uuidv4(),
    keyValue: req.keyRecord.keyValue,
    lessonId: lesson.id,
    completedAt: new Date().toISOString(),
  });

  res.status(201).json({ progress: entry, alreadyCompleted: false });
});

/** GET /api/lessons/progress/summary — ملخص تقدّم هذا المفتاح بالذات */
router.get("/progress/summary", (req, res) => {
  const lessons = db.getAll("lessons");
  const myProgress = db.findMany("progress", (p) => p.keyValue === req.keyRecord.keyValue);

  res.json({
    totalLessons: lessons.length,
    completedLessons: myProgress.length,
    completionPercent: lessons.length
      ? Math.round((myProgress.length / lessons.length) * 100)
      : 0,
  });
});

module.exports = router;
