const express = require("express");
const db = require("../db/store");
const { isExpired } = require("../middleware/keyAuth");

const router = express.Router();

/**
 * POST /api/access/verify
 * body: { keyValue }
 * يفحص صلاحية المفتاح، ويفعّله لأول مرة (يبدأ حساب مدة الصلاحية من أول استخدام)
 */
router.post("/verify", async (req, res) => {
  const { keyValue } = req.body || {};

  if (!keyValue) {
    return res.status(400).json({ error: "أدخل مفتاح التصريح." });
  }

  const keyRecord = db.findOne("keys", (k) => k.keyValue === String(keyValue).trim());

  if (!keyRecord) {
    return res.status(401).json({ valid: false, error: "مفتاح التصريح غير صحيح." });
  }

  if (keyRecord.status === "disabled") {
    return res.status(403).json({ valid: false, error: "تم تعطيل هذا المفتاح. تواصل مع الدعم." });
  }

  // أول استخدام فعلي: تبدأ مدة الصلاحية من هذه اللحظة
  let activeRecord = keyRecord;
  if (!keyRecord.activatedAt) {
    activeRecord = await db.updateById("keys", keyRecord.id, {
      activatedAt: new Date().toISOString(),
    });
  }

  if (isExpired(activeRecord)) {
    return res.status(403).json({ valid: false, error: "انتهت صلاحية مفتاح التصريح." });
  }

  res.json({
    valid: true,
    keyValue: activeRecord.keyValue,
    expiresInDays: activeRecord.durationDays,
  });
});

module.exports = router;
