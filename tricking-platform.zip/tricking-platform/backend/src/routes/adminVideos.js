const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../db/store");
const { requireAdminAuth } = require("../middleware/adminAuth");

const router = express.Router();

const ALLOWED_PLATFORMS = ["youtube", "tiktok", "instagram", "direct"];

router.use(requireAdminAuth);

/** GET /api/admin/videos — كل الفيديوهات (نشطة وغير نشطة) مرتبة بالترتيب */
router.get("/", (req, res) => {
  const videos = db.getAll("videos").sort((a, b) => a.order - b.order);
  res.json({ videos });
});

/**
 * POST /api/admin/videos — إضافة فيديو جديد
 * body: { platform, url, title, orientation?: "portrait"|"landscape", order? }
 */
router.post("/", async (req, res) => {
  const { platform, url, title, orientation = "landscape", order } = req.body || {};

  if (!platform || !ALLOWED_PLATFORMS.includes(platform)) {
    return res.status(400).json({ error: `نوع المصدر يجب أن يكون أحد: ${ALLOWED_PLATFORMS.join(", ")}` });
  }
  if (!url || !title) {
    return res.status(400).json({ error: "الرابط والعنوان مطلوبان." });
  }

  const existingVideos = db.getAll("videos");
  const newOrder = order !== undefined ? Number(order) : existingVideos.length + 1;

  const video = await db.insert("videos", {
    id: uuidv4(),
    platform,
    url,
    title,
    orientation: orientation === "portrait" ? "portrait" : "landscape",
    order: newOrder,
    active: true,
    createdAt: new Date().toISOString(),
  });

  res.status(201).json({ video });
});

/**
 * PATCH /api/admin/videos/:id — تعديل فيديو (الرابط، العنوان، الترتيب، تفعيل/تعطيل)
 */
router.patch("/:id", async (req, res) => {
  const { platform, url, title, orientation, order, active } = req.body || {};
  const updates = {};
  if (platform && ALLOWED_PLATFORMS.includes(platform)) updates.platform = platform;
  if (url) updates.url = url;
  if (title) updates.title = title;
  if (orientation) updates.orientation = orientation === "portrait" ? "portrait" : "landscape";
  if (order !== undefined) updates.order = Number(order);
  if (active !== undefined) updates.active = Boolean(active);

  const updated = await db.updateById("videos", req.params.id, updates);
  if (!updated) return res.status(404).json({ error: "الفيديو غير موجود." });

  res.json({ video: updated });
});

/** DELETE /api/admin/videos/:id */
router.delete("/:id", async (req, res) => {
  const deleted = await db.deleteById("videos", req.params.id);
  if (!deleted) return res.status(404).json({ error: "الفيديو غير موجود." });
  res.json({ success: true });
});

module.exports = router;
