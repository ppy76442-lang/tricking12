/**
 * middleware حماية مسارات الأدمن
 * ---------------------------------------
 * يتحقق من وجود توكن JWT صالح في الهيدر Authorization
 * بصيغة: "Authorization: Bearer <token>"
 */

const jwt = require("jsonwebtoken");

function requireAdminAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: "يلزم تسجيل الدخول للوصول لهذا المسار." });
  }

  try {
    const secret = process.env.JWT_SECRET || "dev-secret-change-me-in-production";
    const payload = jwt.verify(token, secret);
    if (payload.role !== "admin") {
      return res.status(403).json({ error: "صلاحيات غير كافية." });
    }
    req.admin = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: "جلسة الدخول غير صالحة أو منتهية، يرجى تسجيل الدخول مجددًا." });
  }
}

module.exports = { requireAdminAuth };
