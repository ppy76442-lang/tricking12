/**
 * middleware التحقق من مفتاح التصريح (للمستخدم/الزائر)
 * ---------------------------------------
 * يُستخدم في المسارات التي يجب أن يكون فيها الزائر قد أدخل
 * مفتاح تصريح صالح، مثل عرض الدروس أو حفظ التقدم.
 *
 * يتوقع الهيدر: "x-access-key: <key>"
 */

const db = require("../db/store");

function isExpired(keyRecord) {
  if (!keyRecord.activatedAt || !keyRecord.durationDays) return false;
  const activatedAt = new Date(keyRecord.activatedAt).getTime();
  const expiresAt = activatedAt + keyRecord.durationDays * 24 * 60 * 60 * 1000;
  return Date.now() > expiresAt;
}

function requireValidKey(req, res, next) {
  const keyValue = req.headers["x-access-key"];

  if (!keyValue) {
    return res.status(401).json({ error: "مفتاح التصريح مطلوب." });
  }

  const keyRecord = db.findOne("keys", (k) => k.keyValue === keyValue);

  if (!keyRecord) {
    return res.status(401).json({ error: "مفتاح التصريح غير صحيح." });
  }

  if (keyRecord.status === "disabled") {
    return res.status(403).json({ error: "تم تعطيل هذا المفتاح. تواصل مع الدعم." });
  }

  if (isExpired(keyRecord)) {
    return res.status(403).json({ error: "انتهت صلاحية مفتاح التصريح." });
  }

  req.keyRecord = keyRecord;
  next();
}

module.exports = { requireValidKey, isExpired };
