require("dotenv").config();
const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 4000;

// ---------- Middleware عام ----------
app.use(cors());
app.use(express.json({ limit: "1mb" }));

// سجل طلبات مبسط لتتبع الأخطاء أثناء التطوير
app.use((req, res, next) => {
  const time = new Date().toISOString();
  console.log(`[${time}] ${req.method} ${req.path}`);
  next();
});

// ---------- المسارات العامة (الزائر/المستخدم) ----------
app.use("/api/access", require("./routes/access"));
app.use("/api/videos", require("./routes/videos"));
app.use("/api/registrations", require("./routes/registrations"));
app.use("/api/lessons", require("./routes/lessons"));

// ---------- مسارات الأدمن ----------
app.use("/api/admin/login", require("./routes/adminAuth"));
app.use("/api/admin/keys", require("./routes/adminKeys"));
app.use("/api/admin/videos", require("./routes/adminVideos"));
app.use("/api/admin/registrations", require("./routes/adminRegistrations"));
app.use("/api/admin/lessons", require("./routes/adminLessons"));
app.use("/api/admin/progress", require("./routes/adminProgress"));

// ---------- فحص صحة السيرفر ----------
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// ---------- معالجة الأخطاء العامة ----------
app.use((req, res) => {
  res.status(404).json({ error: "المسار غير موجود." });
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error("خطأ غير متوقع:", err);
  res.status(500).json({ error: "حدث خطأ داخلي في السيرفر." });
});

app.listen(PORT, () => {
  console.log(`\n✅ السيرفر يعمل على http://localhost:${PORT}`);
  console.log(`   فحص الصحة: http://localhost:${PORT}/api/health\n`);
});
