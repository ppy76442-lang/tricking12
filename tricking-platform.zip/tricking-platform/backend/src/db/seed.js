/**
 * سكريبت التهيئة الأولية (Seed)
 * ---------------------------------------
 * يُشغَّل مرة واحدة فقط عند إعداد المشروع لأول مرة:
 *   npm run seed
 *
 * ينشئ:
 *  - حساب أدمن افتراضي لتسجيل الدخول إلى لوحة التحكم
 *  - مفتاح تصريح تجريبي واحد للاختبار
 *  - فيديوهين استعراضيين تجريبيين (روابط يوتيوب عامة)
 *  - درس تدريبي تجريبي واحد
 *
 * مهم: غيّر بيانات الأدمن الافتراضية فورًا بعد أول تسجيل دخول في بيئة الإنتاج.
 */

require("dotenv").config();
const { v4: uuidv4 } = require("uuid");
const crypto = require("crypto");
const db = require("./store");

function hashPassword(password) {
  // تجزئة مبسطة باستخدام SHA-256 + salt ثابت من البيئة
  // ملاحظة: لمشروع إنتاجي حقيقي بحركة دخول كبيرة، يُفضّل الانتقال لـ bcrypt
  // عبر تثبيت حزمة bcryptjs لاحقًا (raised في ملف الـ README).
  const salt = process.env.PASSWORD_SALT || "tricking-default-salt-change-me";
  return crypto.createHash("sha256").update(password + salt).digest("hex");
}

function seed() {
  console.log("بدء التهيئة الأولية...\n");

  // 1) حساب الأدمن
  const existingAdmins = db.getAll("admins");
  if (existingAdmins.length === 0) {
    const adminUsername = process.env.SEED_ADMIN_USERNAME || "admin";
    const adminPassword = process.env.SEED_ADMIN_PASSWORD || "ChangeMe123!";
    db.insert("admins", {
      id: uuidv4(),
      username: adminUsername,
      passwordHash: hashPassword(adminPassword),
      createdAt: new Date().toISOString(),
    });
    console.log(`✓ تم إنشاء حساب أدمن:`);
    console.log(`  اسم المستخدم: ${adminUsername}`);
    console.log(`  كلمة المرور: ${adminPassword}`);
    console.log(`  ⚠ غيّر كلمة المرور فورًا من لوحة التحكم بعد أول دخول.\n`);
  } else {
    console.log("✓ يوجد حساب أدمن مسبقًا — تم تجاوز هذه الخطوة.\n");
  }

  // 2) مفتاح تصريح تجريبي
  const existingKeys = db.getAll("keys");
  if (existingKeys.length === 0) {
    const demoKey = "500485896";
    db.insert("keys", {
      id: uuidv4(),
      keyValue: demoKey,
      status: "active", // active | disabled | expired
      durationDays: 30,
      createdAt: new Date().toISOString(),
      activatedAt: null, // تبدأ مدة الصلاحية من أول استخدام فعلي
      note: "مفتاح تجريبي تم إنشاؤه أثناء التهيئة الأولية",
    });
    console.log(`✓ تم إنشاء مفتاح تصريح تجريبي: ${demoKey}\n`);
  } else {
    console.log("✓ توجد مفاتيح مسبقًا — تم تجاوز هذه الخطوة.\n");
  }

  // 3) فيديوهات استعراضية تجريبية
  const existingVideos = db.getAll("videos");
  if (existingVideos.length === 0) {
    const demoVideos = [
      {
        id: uuidv4(),
        platform: "youtube",
        url: "https://www.youtube.com/watch?v=0jh-3aBcupE",
        title: "Gainer Flash & Gainer Switch — عرض تقني",
        orientation: "landscape",
        order: 1,
        active: true,
        createdAt: new Date().toISOString(),
      },
      {
        id: uuidv4(),
        platform: "youtube",
        url: "https://www.youtube.com/watch?v=qKJ5-W0WIcY",
        title: "Cartwheel Full Twist — عرض تقني",
        orientation: "landscape",
        order: 2,
        active: true,
        createdAt: new Date().toISOString(),
      },
    ];
    demoVideos.forEach((v) => db.insert("videos", v));
    console.log(`✓ تم إضافة ${demoVideos.length} فيديو استعراضي تجريبي.\n`);
  } else {
    console.log("✓ توجد فيديوهات مسبقًا — تم تجاوز هذه الخطوة.\n");
  }

  // 4) درس تدريبي تجريبي
  const existingLessons = db.getAll("lessons");
  if (existingLessons.length === 0) {
    db.insert("lessons", {
      id: uuidv4(),
      title: "اليوم 1 — القوة الانفجارية",
      level: "تأسيسي",
      description: "بناء جسم التريكر: بليومتركس عام واستقرار جذع",
      order: 1,
      exercises: [
        { name: "قفزات سكوات", dose: "4×8", videoUrl: "https://www.youtube.com/watch?v=yypw2pWdfpY" },
        { name: "قفزات تاك", dose: "4×6", videoUrl: "https://www.youtube.com/watch?v=I5MEGdA8Lx8" },
      ],
      createdAt: new Date().toISOString(),
    });
    console.log("✓ تم إضافة درس تدريبي تجريبي.\n");
  } else {
    console.log("✓ توجد دروس مسبقًا — تم تجاوز هذه الخطوة.\n");
  }

  console.log("اكتملت التهيئة الأولية بنجاح ✅");
}

seed();
