/**
 * طبقة التخزين (Storage Layer)
 * ---------------------------------------
 * MVP يستخدم ملفات JSON كقاعدة بيانات مبسطة لتسريع الإطلاق الأول
 * بدون الحاجة لتثبيت أو إدارة سيرفر قاعدة بيانات منفصل.
 *
 * مهم جدًا: هذا الملف هو الوحيد الذي يتعامل مباشرة مع نظام الملفات.
 * كل الـ routes تتعامل فقط مع الدوال أدناه (get/insert/update/delete)
 * وليس مع الملفات مباشرة. هذا يسمح لاحقًا بترقية المشروع لقاعدة بيانات
 * حقيقية مثل PostgreSQL أو MySQL عن طريق إعادة كتابة هذا الملف فقط،
 * دون الحاجة لتغيير أي سطر في باقي المشروع.
 *
 * تحذير للتوسع: هذا الأسلوب مناسب لعدد مستخدمين محدود (مئات إلى آلاف).
 * عند نمو المنصة بشكل كبير، يُنصح بالانتقال لقاعدة بيانات حقيقية.
 */

const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "..", "..", "data");

// التأكد من وجود مجلد البيانات
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const COLLECTIONS = ["keys", "registrations", "videos", "lessons", "progress", "admins"];

function filePath(collection) {
  return path.join(DATA_DIR, `${collection}.json`);
}

// تهيئة كل ملف بمصفوفة فارغة لو غير موجود
function ensureFile(collection) {
  const fp = filePath(collection);
  if (!fs.existsSync(fp)) {
    fs.writeFileSync(fp, "[]", "utf-8");
  }
}

COLLECTIONS.forEach(ensureFile);

// قفل كتابة بسيط في الذاكرة لمنع تعارض الكتابة المتزامنة على نفس الملف
const writeLocks = {};

function readCollection(collection) {
  ensureFile(collection);
  const raw = fs.readFileSync(filePath(collection), "utf-8");
  try {
    return JSON.parse(raw || "[]");
  } catch (err) {
    console.error(`خطأ في قراءة ${collection}.json:`, err.message);
    return [];
  }
}

async function writeCollection(collection, data) {
  // كتابة عبر ملف مؤقت ثم استبدال (atomic-ish) لتقليل خطر تلف البيانات
  const fp = filePath(collection);
  const tmp = `${fp}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf-8");
  fs.renameSync(tmp, fp);
}

// قفل تسلسلي بسيط: كل عملية كتابة على نفس المجموعة تنتظر السابقة
function withLock(collection, fn) {
  const prev = writeLocks[collection] || Promise.resolve();
  const next = prev.then(fn, fn);
  writeLocks[collection] = next.catch(() => {});
  return next;
}

const db = {
  /** يرجع كل العناصر في مجموعة */
  getAll(collection) {
    return readCollection(collection);
  },

  /** يبحث عن عنصر واحد بشرط (predicate function) */
  findOne(collection, predicate) {
    return readCollection(collection).find(predicate) || null;
  },

  /** يبحث عن كل العناصر المطابقة لشرط */
  findMany(collection, predicate) {
    return readCollection(collection).filter(predicate);
  },

  /** يضيف عنصر جديد ويرجعه */
  insert(collection, item) {
    return withLock(collection, async () => {
      const items = readCollection(collection);
      items.push(item);
      await writeCollection(collection, items);
      return item;
    });
  },

  /** يحدّث عنصر بحسب id، يرجع العنصر المحدث أو null لو غير موجود */
  updateById(collection, id, updates) {
    return withLock(collection, async () => {
      const items = readCollection(collection);
      const idx = items.findIndex((i) => i.id === id);
      if (idx === -1) return null;
      items[idx] = { ...items[idx], ...updates };
      await writeCollection(collection, items);
      return items[idx];
    });
  },

  /** يحذف عنصر بحسب id، يرجع true لو تم الحذف */
  deleteById(collection, id) {
    return withLock(collection, async () => {
      const items = readCollection(collection);
      const next = items.filter((i) => i.id !== id);
      const changed = next.length !== items.length;
      if (changed) await writeCollection(collection, next);
      return changed;
    });
  },
};

module.exports = db;
