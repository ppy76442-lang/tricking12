# في وضع التطوير المحلي، لا حاجة لأي شيء هنا — vite.config.js يوجّه
# طلبات /api تلقائيًا إلى http://localhost:4000 (الباك إند).
#
# عند النشر على الإنترنت، الفرونت إند والباك إند سيكونان على عنوانين مختلفين
# (مثلاً: frontend على Vercel، backend على Railway).
# في هذه الحالة، عدّل BASE_URL في الملف src/api/client.js
# من "/api" إلى رابط الباك إند الكامل، مثل:
# "https://your-backend-app.up.railway.app/api"
