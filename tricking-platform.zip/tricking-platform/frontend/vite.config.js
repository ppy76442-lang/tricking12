import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      // أثناء التطوير المحلي، يتم توجيه طلبات /api مباشرة للباك إند
      // (شغّل الباك إند على المنفذ 4000 قبل تشغيل الفرونت إند)
      "/api": {
        target: "http://localhost:4000",
        changeOrigin: true,
      },
    },
  },
});
