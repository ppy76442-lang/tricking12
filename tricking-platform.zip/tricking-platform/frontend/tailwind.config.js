/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0c0d0f",
        paper: "#f2efe7",
        rust: "#e1481c",
        rustdim: "#9c3415",
        chalk: "#d8d2c0",
        line: "#3a3a36",
        ok: "#7a9b6e",
      },
      fontFamily: {
        display: ["Tahoma", "Arial Narrow", "sans-serif"],
        body: ["Tahoma", "Segoe UI", "sans-serif"],
        mono: ["Courier New", "monospace"],
      },
    },
  },
  plugins: [],
};
