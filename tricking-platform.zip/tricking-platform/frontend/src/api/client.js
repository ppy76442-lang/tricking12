/**
 * طبقة API الموحدة
 * ---------------------------------------
 * كل طلبات الشبكة في التطبيق تمر من هنا، بحيث لو تغيّر عنوان السيرفر
 * أو طريقة التوثيق لاحقًا، يتم التعديل في مكان واحد فقط.
 */

const BASE_URL = "/api"; // في الإنتاج: يمكن استبدالها بعنوان السيرفر الكامل عبر متغير بيئة Vite

function getAdminToken() {
  return localStorage.getItem("admin_token");
}

function getAccessKey() {
  return sessionStorage.getItem("access_key");
}

async function request(path, { method = "GET", body, auth = false, useKey = false } = {}) {
  const headers = { "Content-Type": "application/json" };

  if (auth) {
    const token = getAdminToken();
    if (token) headers["Authorization"] = `Bearer ${token}`;
  }
  if (useKey) {
    const key = getAccessKey();
    if (key) headers["x-access-key"] = key;
  }

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  let data = null;
  try {
    data = await res.json();
  } catch {
    data = null;
  }

  if (!res.ok) {
    const message = data?.error || "حدث خطأ غير متوقع في الاتصال بالسيرفر.";
    throw new Error(message);
  }

  return data;
}

export const api = {
  // ---- عام (الزائر) ----
  verifyKey: (keyValue) => request("/access/verify", { method: "POST", body: { keyValue } }),
  getVideos: () => request("/videos"),
  submitRegistration: (payload) =>
    request("/registrations", { method: "POST", body: payload }),
  getLessons: () => request("/lessons", { useKey: true }),
  completeLesson: (id) => request(`/lessons/${id}/complete`, { method: "POST", useKey: true }),
  getMyProgress: () => request("/lessons/progress/summary", { useKey: true }),

  // ---- أدمن ----
  adminLogin: (username, password) =>
    request("/admin/login", { method: "POST", body: { username, password } }),

  adminGetKeys: () => request("/admin/keys", { auth: true }),
  adminCreateKey: (payload) => request("/admin/keys", { method: "POST", body: payload, auth: true }),
  adminUpdateKey: (id, payload) =>
    request(`/admin/keys/${id}`, { method: "PATCH", body: payload, auth: true }),
  adminDeleteKey: (id) => request(`/admin/keys/${id}`, { method: "DELETE", auth: true }),

  adminGetVideos: () => request("/admin/videos", { auth: true }),
  adminCreateVideo: (payload) =>
    request("/admin/videos", { method: "POST", body: payload, auth: true }),
  adminUpdateVideo: (id, payload) =>
    request(`/admin/videos/${id}`, { method: "PATCH", body: payload, auth: true }),
  adminDeleteVideo: (id) => request(`/admin/videos/${id}`, { method: "DELETE", auth: true }),

  adminGetRegistrations: () => request("/admin/registrations", { auth: true }),
  adminUpdateRegistration: (id, status) =>
    request(`/admin/registrations/${id}`, { method: "PATCH", body: { status }, auth: true }),
  adminDeleteRegistration: (id) =>
    request(`/admin/registrations/${id}`, { method: "DELETE", auth: true }),

  adminGetLessons: () => request("/admin/lessons", { auth: true }),
  adminCreateLesson: (payload) =>
    request("/admin/lessons", { method: "POST", body: payload, auth: true }),
  adminUpdateLesson: (id, payload) =>
    request(`/admin/lessons/${id}`, { method: "PATCH", body: payload, auth: true }),
  adminDeleteLesson: (id) => request(`/admin/lessons/${id}`, { method: "DELETE", auth: true }),

  adminGetProgress: () => request("/admin/progress", { auth: true }),
};

export function saveAdminToken(token) {
  localStorage.setItem("admin_token", token);
}
export function clearAdminToken() {
  localStorage.removeItem("admin_token");
}
export function isAdminLoggedIn() {
  return Boolean(getAdminToken());
}

export function saveAccessKey(key) {
  sessionStorage.setItem("access_key", key);
}
export function clearAccessKey() {
  sessionStorage.removeItem("access_key");
}
export function hasAccessKey() {
  return Boolean(getAccessKey());
}
