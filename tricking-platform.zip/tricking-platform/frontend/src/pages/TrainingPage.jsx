import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, hasAccessKey } from "../api/client.js";
import AccessGate from "../components/AccessGate.jsx";
import VideoPlayer from "../components/VideoPlayer.jsx";

export default function TrainingPage() {
  const navigate = useNavigate();
  const [unlocked, setUnlocked] = useState(hasAccessKey());
  const [lessons, setLessons] = useState([]);
  const [progress, setProgress] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!unlocked) return;
    Promise.all([api.getLessons(), api.getMyProgress()])
      .then(([lessonsData, progressData]) => {
        setLessons(lessonsData.lessons);
        setProgress(progressData);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [unlocked]);

  async function markComplete(lessonId) {
    try {
      await api.completeLesson(lessonId);
      setLessons((prev) =>
        prev.map((l) => (l.id === lessonId ? { ...l, completed: true } : l))
      );
      const updatedProgress = await api.getMyProgress();
      setProgress(updatedProgress);
    } catch (err) {
      setError(err.message);
    }
  }

  if (!unlocked) {
    return <AccessGate onUnlocked={() => setUnlocked(true)} />;
  }

  return (
    <div className="min-h-screen bg-ink text-paper font-body px-6 py-8">
      <button onClick={() => navigate("/")} className="text-chalk/60 text-sm mb-6">
        ← رجوع للرئيسية
      </button>

      <h1 className="font-display font-extrabold text-3xl mb-2">الخطة التدريبية</h1>
      <p className="text-chalk/70 mb-6">تابع تقدمك خطوة بخطوة — كل درس مكتمل يقرّبك من الدمج الكامل.</p>

      {progress && (
        <div className="mb-8 bg-[#15161a] border border-line rounded-lg p-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-chalk/80">تقدّمك الإجمالي</span>
            <span className="font-mono text-rust text-sm">{progress.completionPercent}%</span>
          </div>
          <div className="h-2 bg-line rounded-full overflow-hidden">
            <div
              className="h-full bg-rust transition-all duration-500"
              style={{ width: `${progress.completionPercent}%` }}
            />
          </div>
          <p className="text-chalk/50 text-xs mt-2">
            {progress.completedLessons} من {progress.totalLessons} درس مكتمل
          </p>
        </div>
      )}

      {error && <p className="text-rust text-sm mb-4">{error}</p>}
      {loading && <p className="text-chalk/50 text-sm">جارٍ تحميل الدروس...</p>}

      <div className="flex flex-col gap-4">
        {lessons.map((lesson) => (
          <LessonCard key={lesson.id} lesson={lesson} onComplete={() => markComplete(lesson.id)} />
        ))}
      </div>

      {!loading && lessons.length === 0 && (
        <p className="text-chalk/50 text-sm">لا توجد دروس متاحة حاليًا.</p>
      )}
    </div>
  );
}

function LessonCard({ lesson, onComplete }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className={`border rounded-lg overflow-hidden transition-colors ${lesson.completed ? "border-ok/50" : "border-line"}`}>
      <button
        onClick={() => setExpanded((e) => !e)}
        className="w-full flex items-center justify-between gap-3 p-4 text-right bg-[#15161a]"
      >
        <div className="flex items-center gap-3">
          <span
            className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
              lesson.completed ? "bg-ok text-ink" : "bg-line text-chalk/60"
            }`}
          >
            {lesson.completed ? "✓" : lesson.order}
          </span>
          <div>
            <p className="font-display font-bold">{lesson.title}</p>
            {lesson.level && <p className="text-chalk/50 text-xs font-mono">{lesson.level}</p>}
          </div>
        </div>
        <span className="text-chalk/40 text-sm">{expanded ? "−" : "+"}</span>
      </button>

      {expanded && (
        <div className="p-4 border-t border-line bg-ink/50">
          {lesson.description && <p className="text-chalk/70 text-sm mb-4">{lesson.description}</p>}

          <div className="flex flex-col gap-4">
            {(lesson.exercises || []).map((ex, i) => (
              <div key={i} className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm">{ex.name}</span>
                  {ex.dose && (
                    <span className="font-mono text-xs bg-rust text-white px-2 py-0.5 rounded">{ex.dose}</span>
                  )}
                </div>
                {ex.videoUrl && (
                  <VideoPlayer platform="youtube" url={ex.videoUrl} orientation="landscape" title={ex.name} />
                )}
              </div>
            ))}
          </div>

          {!lesson.completed && (
            <button
              onClick={onComplete}
              className="mt-4 w-full bg-rust hover:bg-rustdim transition-colors text-white font-bold rounded-md py-2.5 text-sm"
            >
              تحديد كمكتمل
            </button>
          )}
        </div>
      )}
    </div>
  );
}
