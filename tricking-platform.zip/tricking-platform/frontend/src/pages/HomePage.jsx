import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { hasAccessKey } from "../api/client.js";
import { api } from "../api/client.js";
import AccessGate from "../components/AccessGate.jsx";
import VideoPlayer from "../components/VideoPlayer.jsx";
import RegistrationForm from "../components/RegistrationForm.jsx";

export default function HomePage() {
  const navigate = useNavigate();
  const [unlocked, setUnlocked] = useState(hasAccessKey());
  const [videos, setVideos] = useState([]);
  const [loadingVideos, setLoadingVideos] = useState(true);
  const [showRegistration, setShowRegistration] = useState(false);

  useEffect(() => {
    api
      .getVideos()
      .then((data) => setVideos(data.videos))
      .catch(() => setVideos([]))
      .finally(() => setLoadingVideos(false));
  }, []);

  if (!unlocked) {
    return <AccessGate onUnlocked={() => setUnlocked(true)} />;
  }

  return (
    <div className="min-h-screen bg-ink text-paper font-body">
      {/* ===== Hero ===== */}
      <section className="px-6 pt-14 pb-10 border-b border-line">
        <p className="font-mono text-rust text-xs tracking-[0.3em] uppercase mb-3">
          منصة تعليم Tricking
        </p>
        <h1 className="font-display font-extrabold text-4xl leading-tight mb-4">
          ابدأ مسارك في
          <span className="text-rust block">رياضة التريكنغ.</span>
        </h1>
        <p className="text-chalk/80 max-w-md mb-6">
          خطة تدريبية متدرجة، فيديوهات تعليمية، ومتابعة تقدّم حقيقية — من أول قفزة إلى أول دمج حركي كامل.
        </p>
        <button
          onClick={() => setShowRegistration(true)}
          className="bg-rust hover:bg-rustdim transition-colors text-white font-bold rounded-md px-7 py-3.5 shadow-lg shadow-rust/20"
        >
          انضم للبرنامج التدريبي الآن
        </button>
      </section>

      {/* ===== فيديوهات استعراضية ===== */}
      <section className="px-6 py-10">
        <h2 className="font-display font-bold text-xl mb-1">شاهد ممارسين حقيقيين</h2>
        <p className="text-chalk/60 text-sm mb-5">حركات منفّذة بمستوى عالٍ — هذا ما ستتمكن من الوصول إليه تدريجيًا</p>

        {loadingVideos ? (
          <p className="text-chalk/50 text-sm">جارٍ تحميل الفيديوهات...</p>
        ) : videos.length === 0 ? (
          <p className="text-chalk/50 text-sm">لا توجد فيديوهات معروضة حاليًا.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {videos.map((v) => (
              <div key={v.id} className="flex flex-col gap-2">
                <VideoPlayer platform={v.platform} url={v.url} orientation={v.orientation} title={v.title} />
                <p className="text-chalk/70 text-sm">{v.title}</p>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* ===== بناء الثقة ===== */}
      <section className="px-6 py-10 border-t border-line grid grid-cols-3 gap-4 text-center">
        <Stat number="4" label="أسابيع للمسار" />
        <Stat number="60" label="دقيقة/جلسة" />
        <Stat number="7" label="أيام مخطّطة" />
      </section>

      {/* ===== الانتقال لقسم التدريب ===== */}
      <section className="px-6 py-12 border-t border-line text-center">
        <h2 className="font-display font-bold text-2xl mb-3">جاهز تشوف خطتك الكاملة؟</h2>
        <p className="text-chalk/70 mb-6 max-w-sm mx-auto">
          كل التمارين، الشرح، الصور، والفيديوهات التعليمية — منظمة حسب يوم الأسبوع.
        </p>
        <button
          onClick={() => navigate("/training")}
          className="border border-rust text-rust hover:bg-rust hover:text-white transition-colors font-bold rounded-md px-7 py-3"
        >
          الذهاب لقسم التدريب
        </button>
      </section>

      <footer className="px-6 py-8 border-t border-line text-center text-chalk/40 text-xs">
        منصة تعليم التريكنغ — جودة التنفيذ أولًا، الكمية ثانيًا.
      </footer>

      {showRegistration && <RegistrationForm onClose={() => setShowRegistration(false)} />}
    </div>
  );
}

function Stat({ number, label }) {
  return (
    <div>
      <p className="font-display font-extrabold text-3xl text-rust">{number}</p>
      <p className="text-chalk/60 text-xs font-mono uppercase tracking-wide mt-1">{label}</p>
    </div>
  );
}
