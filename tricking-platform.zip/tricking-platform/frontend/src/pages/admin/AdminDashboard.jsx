import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import AdminNav from "./AdminNav.jsx";
import KeysManager from "./KeysManager.jsx";
import VideosManager from "./VideosManager.jsx";
import RegistrationsManager from "./RegistrationsManager.jsx";
import LessonsManager from "./LessonsManager.jsx";
import ProgressOverview from "./ProgressOverview.jsx";

export default function AdminDashboard() {
  return (
    <div className="min-h-screen bg-ink text-paper font-body">
      <AdminNav />
      <Routes>
        <Route index element={<Navigate to="keys" replace />} />
        <Route path="keys" element={<KeysManager />} />
        <Route path="videos" element={<VideosManager />} />
        <Route path="registrations" element={<RegistrationsManager />} />
        <Route path="lessons" element={<LessonsManager />} />
        <Route path="progress" element={<ProgressOverview />} />
      </Routes>
    </div>
  );
}
