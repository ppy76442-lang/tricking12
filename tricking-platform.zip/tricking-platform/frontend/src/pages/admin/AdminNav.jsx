import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { clearAdminToken } from "../../api/client.js";

const links = [
  { to: "/admin/keys", label: "مفاتيح التصريح" },
  { to: "/admin/videos", label: "الفيديوهات" },
  { to: "/admin/registrations", label: "طلبات التسجيل" },
  { to: "/admin/lessons", label: "الدروس والخطط" },
  { to: "/admin/progress", label: "تقدّم المشتركين" },
];

export default function AdminNav() {
  const navigate = useNavigate();

  function logout() {
    clearAdminToken();
    navigate("/admin/login");
  }

  return (
    <nav className="bg-[#15161a] border-b border-line px-4 py-3 flex items-center gap-1 overflow-x-auto">
      <span className="font-display font-bold text-rust ml-4 flex-shrink-0">لوحة التحكم</span>
      {links.map((l) => (
        <NavLink
          key={l.to}
          to={l.to}
          className={({ isActive }) =>
            `px-3 py-2 rounded-md text-sm whitespace-nowrap transition-colors ${
              isActive ? "bg-rust text-white" : "text-chalk/70 hover:text-paper"
            }`
          }
        >
          {l.label}
        </NavLink>
      ))}
      <button
        onClick={logout}
        className="mr-auto px-3 py-2 text-sm text-chalk/50 hover:text-rust flex-shrink-0"
      >
        خروج
      </button>
    </nav>
  );
}
