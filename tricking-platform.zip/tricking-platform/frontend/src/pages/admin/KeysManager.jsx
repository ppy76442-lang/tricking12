import React, { useEffect, useState } from "react";
import { api } from "../../api/client.js";

export default function KeysManager() {
  const [keys, setKeys] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [creating, setCreating] = useState(false);
  const [durationDays, setDurationDays] = useState(30);
  const [note, setNote] = useState("");
  const [customKey, setCustomKey] = useState("");

  function load() {
    setLoading(true);
    api
      .adminGetKeys()
      .then((data) => setKeys(data.keys))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function handleCreate(e) {
    e.preventDefault();
    setCreating(true);
    setError("");
    try {
      await api.adminCreateKey({
        durationDays: Number(durationDays),
        note,
        customKey: customKey.trim() || undefined,
      });
      setNote("");
      setCustomKey("");
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setCreating(false);
    }
  }

  async function toggleStatus(key) {
    const newStatus = key.status === "disabled" ? "active" : "disabled";
    await api.adminUpdateKey(key.id, { status: newStatus });
    load();
  }

  async function remove(key) {
    if (!confirm(`حذف المفتاح ${key.keyValue} نهائيًا؟`)) return;
    await api.adminDeleteKey(key.id);
    load();
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="font-display font-bold text-2xl text-paper mb-5">مفاتيح التصريح</h2>

      <form onSubmit={handleCreate} className="bg-[#15161a] border border-line rounded-lg p-4 mb-6 flex flex-wrap gap-3 items-end">
        <Field label="مدة الصلاحية (أيام)">
          <input
            type="number"
            value={durationDays}
            onChange={(e) => setDurationDays(e.target.value)}
            className="bg-[#191a1b] border border-line rounded-md px-3 py-2 text-paper w-28 focus:outline-none focus:border-rust"
          />
        </Field>
        <Field label="ملاحظة (اختياري)">
          <input
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="مثال: دفعة يونيو"
            className="bg-[#191a1b] border border-line rounded-md px-3 py-2 text-paper w-44 focus:outline-none focus:border-rust"
          />
        </Field>
        <Field label="مفتاح مخصص (اختياري)">
          <input
            type="text"
            value={customKey}
            onChange={(e) => setCustomKey(e.target.value)}
            placeholder="اتركه فارغًا للتوليد التلقائي"
            className="bg-[#191a1b] border border-line rounded-md px-3 py-2 text-paper w-52 focus:outline-none focus:border-rust"
          />
        </Field>
        <button
          type="submit"
          disabled={creating}
          className="bg-rust hover:bg-rustdim disabled:opacity-50 transition-colors text-white font-bold rounded-md px-5 py-2.5"
        >
          {creating ? "جارٍ الإنشاء..." : "إنشاء مفتاح جديد"}
        </button>
      </form>

      {error && <p className="text-rust text-sm mb-4">{error}</p>}
      {loading ? (
        <p className="text-chalk/50 text-sm">جارٍ التحميل...</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="border-b border-line text-chalk/60 text-right">
                <th className="py-2 px-2">المفتاح</th>
                <th className="py-2 px-2">الحالة</th>
                <th className="py-2 px-2">المدة</th>
                <th className="py-2 px-2">تاريخ التفعيل</th>
                <th className="py-2 px-2">ملاحظة</th>
                <th className="py-2 px-2">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {keys.map((k) => (
                <tr key={k.id} className="border-b border-line/50">
                  <td className="py-2 px-2 font-mono">{k.keyValue}</td>
                  <td className="py-2 px-2">
                    <StatusBadge status={k.effectiveStatus} />
                  </td>
                  <td className="py-2 px-2">{k.durationDays} يوم</td>
                  <td className="py-2 px-2 text-chalk/60">
                    {k.activatedAt ? new Date(k.activatedAt).toLocaleDateString("ar") : "لم يُستخدم بعد"}
                  </td>
                  <td className="py-2 px-2 text-chalk/60">{k.note}</td>
                  <td className="py-2 px-2 flex gap-2">
                    <button onClick={() => toggleStatus(k)} className="text-rust hover:underline">
                      {k.status === "disabled" ? "تفعيل" : "تعطيل"}
                    </button>
                    <button onClick={() => remove(k)} className="text-chalk/50 hover:text-rust hover:underline">
                      حذف
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {keys.length === 0 && <p className="text-chalk/50 text-sm mt-4">لا توجد مفاتيح بعد.</p>}
        </div>
      )}
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label className="flex flex-col gap-1 text-xs text-chalk/70">
      {label}
      {children}
    </label>
  );
}

function StatusBadge({ status }) {
  const map = {
    active: { label: "فعّال", cls: "bg-ok/20 text-ok" },
    disabled: { label: "معطّل", cls: "bg-chalk/10 text-chalk/60" },
    expired: { label: "منتهي", cls: "bg-rust/20 text-rust" },
  };
  const s = map[status] || map.active;
  return <span className={`px-2 py-0.5 rounded text-xs font-mono ${s.cls}`}>{s.label}</span>;
}
