import React, { useEffect, useState } from "react";
import { api } from "../../api/client.js";

const emptyExercise = { name: "", dose: "", videoUrl: "" };
const emptyLesson = { title: "", level: "", description: "", exercises: [{ ...emptyExercise }] };

export default function LessonsManager() {
  const [lessons, setLessons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [form, setForm] = useState(emptyLesson);
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState(null);

  function load() {
    setLoading(true);
    api
      .adminGetLessons()
      .then((data) => setLessons(data.lessons))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  function updateExercise(idx, field, value) {
    setForm((f) => {
      const exercises = [...f.exercises];
      exercises[idx] = { ...exercises[idx], [field]: value };
      return { ...f, exercises };
    });
  }

  function addExerciseRow() {
    setForm((f) => ({ ...f, exercises: [...f.exercises, { ...emptyExercise }] }));
  }

  function removeExerciseRow(idx) {
    setForm((f) => ({ ...f, exercises: f.exercises.filter((_, i) => i !== idx) }));
  }

  function startEdit(lesson) {
    setEditingId(lesson.id);
    setForm({
      title: lesson.title,
      level: lesson.level || "",
      description: lesson.description || "",
      exercises: lesson.exercises?.length ? lesson.exercises : [{ ...emptyExercise }],
    });
  }

  function cancelEdit() {
    setEditingId(null);
    setForm(emptyLesson);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.title.trim()) {
      setError("عنوان الدرس مطلوب.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      const cleanExercises = form.exercises.filter((ex) => ex.name.trim());
      if (editingId) {
        await api.adminUpdateLesson(editingId, { ...form, exercises: cleanExercises });
      } else {
        await api.adminCreateLesson({ ...form, exercises: cleanExercises });
      }
      cancelEdit();
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function remove(lesson) {
    if (!confirm(`حذف الدرس "${lesson.title}"؟`)) return;
    await api.adminDeleteLesson(lesson.id);
    load();
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="font-display font-bold text-2xl text-paper mb-5">الدروس والخطط التدريبية</h2>

      <form onSubmit={handleSubmit} className="bg-[#15161a] border border-line rounded-lg p-4 mb-6 flex flex-col gap-3">
        <p className="text-chalk/60 text-sm">{editingId ? "تعديل درس" : "إضافة درس جديد"}</p>

        <input
          type="text"
          value={form.title}
          onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
          placeholder="عنوان الدرس (مثال: اليوم 1 — القوة الانفجارية)"
          className="bg-[#191a1b] border border-line rounded-md px-3 py-2 text-paper focus:outline-none focus:border-rust"
        />
        <div className="flex gap-3">
          <input
            type="text"
            value={form.level}
            onChange={(e) => setForm((f) => ({ ...f, level: e.target.value }))}
            placeholder="المستوى (مثال: تأسيسي / متقدم)"
            className="flex-1 bg-[#191a1b] border border-line rounded-md px-3 py-2 text-paper focus:outline-none focus:border-rust"
          />
        </div>
        <textarea
          value={form.description}
          onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
          placeholder="وصف مختصر للدرس"
          rows={2}
          className="bg-[#191a1b] border border-line rounded-md px-3 py-2 text-paper focus:outline-none focus:border-rust resize-none"
        />

        <p className="text-chalk/60 text-sm mt-2">التمارين</p>
        {form.exercises.map((ex, idx) => (
          <div key={idx} className="flex flex-wrap gap-2 items-center">
            <input
              type="text"
              value={ex.name}
              onChange={(e) => updateExercise(idx, "name", e.target.value)}
              placeholder="اسم التمرين"
              className="flex-1 min-w-[140px] bg-[#191a1b] border border-line rounded-md px-3 py-2 text-paper text-sm"
            />
            <input
              type="text"
              value={ex.dose}
              onChange={(e) => updateExercise(idx, "dose", e.target.value)}
              placeholder="مثال: 4×8"
              className="w-24 bg-[#191a1b] border border-line rounded-md px-3 py-2 text-paper text-sm"
            />
            <input
              type="text"
              value={ex.videoUrl}
              onChange={(e) => updateExercise(idx, "videoUrl", e.target.value)}
              placeholder="رابط فيديو يوتيوب (اختياري)"
              className="flex-1 min-w-[160px] bg-[#191a1b] border border-line rounded-md px-3 py-2 text-paper text-sm"
            />
            <button type="button" onClick={() => removeExerciseRow(idx)} className="text-chalk/50 hover:text-rust text-sm">
              حذف
            </button>
          </div>
        ))}
        <button type="button" onClick={addExerciseRow} className="text-rust text-sm self-start hover:underline">
          + إضافة تمرين آخر
        </button>

        {error && <p className="text-rust text-sm">{error}</p>}

        <div className="flex gap-2 mt-2">
          {editingId && (
            <button type="button" onClick={cancelEdit} className="border border-line text-chalk rounded-md px-5 py-2.5">
              إلغاء
            </button>
          )}
          <button
            type="submit"
            disabled={saving}
            className="bg-rust hover:bg-rustdim disabled:opacity-50 transition-colors text-white font-bold rounded-md px-6 py-2.5"
          >
            {saving ? "جارٍ الحفظ..." : editingId ? "حفظ التعديلات" : "إضافة الدرس"}
          </button>
        </div>
      </form>

      {loading ? (
        <p className="text-chalk/50 text-sm">جارٍ التحميل...</p>
      ) : (
        <div className="flex flex-col gap-3">
          {lessons.map((lesson) => (
            <div key={lesson.id} className="bg-[#15161a] border border-line rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-bold text-paper">{lesson.title}</p>
                  <p className="text-chalk/50 text-xs">{lesson.exercises?.length || 0} تمرين</p>
                </div>
                <div className="flex gap-3 text-sm">
                  <button onClick={() => startEdit(lesson)} className="text-rust hover:underline">
                    تعديل
                  </button>
                  <button onClick={() => remove(lesson)} className="text-chalk/50 hover:text-rust hover:underline">
                    حذف
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      {!loading && lessons.length === 0 && <p className="text-chalk/50 text-sm">لا توجد دروس بعد.</p>}
    </div>
  );
}
