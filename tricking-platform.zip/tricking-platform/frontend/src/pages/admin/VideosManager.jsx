import React, { useEffect, useState } from "react";
import { api } from "../../api/client.js";
import VideoPlayer from "../../components/VideoPlayer.jsx";

const PLATFORMS = [
  { value: "youtube", label: "يوتيوب" },
  { value: "tiktok", label: "تيك توك" },
  { value: "instagram", label: "إنستغرام" },
  { value: "direct", label: "رابط مباشر / ملف مرفوع" },
];

export default function VideosManager() {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    platform: "youtube",
    url: "",
    title: "",
    orientation: "landscape",
  });
  const [saving, setSaving] = useState(false);

  function load() {
    setLoading(true);
    api
      .adminGetVideos()
      .then((data) => setVideos(data.videos))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function handleCreate(e) {
    e.preventDefault();
    if (!form.url || !form.title) {
      setError("الرابط والعنوان مطلوبان.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await api.adminCreateVideo(form);
      setForm({ platform: "youtube", url: "", title: "", orientation: "landscape" });
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function toggleActive(v) {
    await api.adminUpdateVideo(v.id, { active: !v.active });
    load();
  }

  async function remove(v) {
    if (!confirm(`حذف الفيديو "${v.title}"؟`)) return;
    await api.adminDeleteVideo(v.id);
    load();
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="font-display font-bold text-2xl text-paper mb-5">إدارة الفيديوهات</h2>

      <form onSubmit={handleCreate} className="bg-[#15161a] border border-line rounded-lg p-4 mb-6 flex flex-col gap-3">
        <div className="flex flex-wrap gap-3">
          <select
            value={form.platform}
            onChange={(e) => setForm((f) => ({ ...f, platform: e.target.value }))}
            className="bg-[#191a1b] border border-line rounded-md px-3 py-2 text-paper"
          >
            {PLATFORMS.map((p) => (
              <option key={p.value} value={p.value}>
                {p.label}
              </option>
            ))}
          </select>

          <select
            value={form.orientation}
            onChange={(e) => setForm((f) => ({ ...f, orientation: e.target.value }))}
            className="bg-[#191a1b] border border-line rounded-md px-3 py-2 text-paper"
          >
            <option value="landscape">أفقي</option>
            <option value="portrait">عمودي</option>
          </select>
        </div>

        <input
          type="text"
          value={form.title}
          onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
          placeholder="عنوان الفيديو"
          className="bg-[#191a1b] border border-line rounded-md px-3 py-2 text-paper focus:outline-none focus:border-rust"
        />
        <input
          type="text"
          value={form.url}
          onChange={(e) => setForm((f) => ({ ...f, url: e.target.value }))}
          placeholder="رابط الفيديو (يوتيوب/تيك توك/إنستغرام/مباشر)"
          className="bg-[#191a1b] border border-line rounded-md px-3 py-2 text-paper focus:outline-none focus:border-rust"
        />

        {error && <p className="text-rust text-sm">{error}</p>}

        <button
          type="submit"
          disabled={saving}
          className="bg-rust hover:bg-rustdim disabled:opacity-50 transition-colors text-white font-bold rounded-md py-2.5 self-start px-6"
        >
          {saving ? "جارٍ الإضافة..." : "إضافة فيديو"}
        </button>
      </form>

      {loading ? (
        <p className="text-chalk/50 text-sm">جارٍ التحميل...</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {videos.map((v) => (
            <div key={v.id} className="bg-[#15161a] border border-line rounded-lg p-3">
              <VideoPlayer platform={v.platform} url={v.url} orientation={v.orientation} title={v.title} autoPlay={false} />
              <div className="flex items-center justify-between mt-2">
                <p className="text-sm text-paper truncate">{v.title}</p>
                <span className={`text-xs font-mono px-2 py-0.5 rounded ${v.active ? "bg-ok/20 text-ok" : "bg-chalk/10 text-chalk/50"}`}>
                  {v.active ? "نشط" : "معطّل"}
                </span>
              </div>
              <div className="flex gap-3 mt-2 text-sm">
                <button onClick={() => toggleActive(v)} className="text-rust hover:underline">
                  {v.active ? "تعطيل" : "تفعيل"}
                </button>
                <button onClick={() => remove(v)} className="text-chalk/50 hover:text-rust hover:underline">
                  حذف
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
      {!loading && videos.length === 0 && <p className="text-chalk/50 text-sm">لا توجد فيديوهات بعد.</p>}
    </div>
  );
}
