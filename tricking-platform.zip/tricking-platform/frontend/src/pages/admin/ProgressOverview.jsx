import React, { useEffect, useState } from "react";
import { api } from "../../api/client.js";

export default function ProgressOverview() {
  const [summary, setSummary] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .adminGetProgress()
      .then((data) => setSummary(data.summary))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="font-display font-bold text-2xl text-paper mb-5">تقدّم المشتركين</h2>

      {error && <p className="text-rust text-sm mb-4">{error}</p>}
      {loading ? (
        <p className="text-chalk/50 text-sm">جارٍ التحميل...</p>
      ) : (
        <div className="flex flex-col gap-3">
          {summary.map((s) => (
            <div key={s.keyValue} className="bg-[#15161a] border border-line rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="font-mono text-paper">{s.keyValue}</span>
                <span className="text-chalk/60 text-xs">{s.note}</span>
                <span className="font-mono text-rust text-sm">{s.completionPercent}%</span>
              </div>
              <div className="h-1.5 bg-line rounded-full overflow-hidden mb-2">
                <div className="h-full bg-rust" style={{ width: `${s.completionPercent}%` }} />
              </div>
              <p className="text-chalk/50 text-xs">
                {s.completedLessons} من {s.totalLessons} درس —{" "}
                {s.lastActivity ? `آخر نشاط: ${new Date(s.lastActivity).toLocaleDateString("ar")}` : "لا يوجد نشاط بعد"}
              </p>
            </div>
          ))}
        </div>
      )}
      {!loading && summary.length === 0 && <p className="text-chalk/50 text-sm">لا توجد بيانات تقدّم بعد.</p>}
    </div>
  );
}
