import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, saveAdminToken } from "../../api/client.js";

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const result = await api.adminLogin(username, password);
      saveAdminToken(result.token);
      navigate("/admin/keys");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-ink flex items-center justify-center px-6">
      <form onSubmit={handleSubmit} className="w-full max-w-sm flex flex-col gap-3">
        <p className="font-mono text-rust text-xs tracking-widest uppercase text-center mb-2">
          لوحة التحكم
        </p>
        <h1 className="font-display font-extrabold text-2xl text-paper text-center mb-6">
          تسجيل دخول الأدمن
        </h1>

        <input
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="اسم المستخدم"
          className="bg-[#191a1b] border border-line rounded-md px-4 py-3 text-paper focus:outline-none focus:border-rust"
          autoFocus
        />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="كلمة المرور"
          className="bg-[#191a1b] border border-line rounded-md px-4 py-3 text-paper focus:outline-none focus:border-rust"
        />

        {error && <p className="text-rust text-sm text-center">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="bg-rust hover:bg-rustdim disabled:opacity-50 transition-colors text-white font-bold rounded-md py-3 mt-2"
        >
          {loading ? "جارٍ الدخول..." : "دخول"}
        </button>
      </form>
    </div>
  );
}
