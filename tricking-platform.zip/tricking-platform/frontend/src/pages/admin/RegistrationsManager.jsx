import React, { useEffect, useState } from "react";
import { api } from "../../api/client.js";

const STATUS_LABELS = {
  pending: { label: "قيد الانتظار", cls: "bg-chalk/10 text-chalk/70" },
  contacted: { label: "تم التواصل", cls: "bg-rust/20 text-rust" },
  approved: { label: "مقبول", cls: "bg-ok/20 text-ok" },
  rejected: { label: "مرفوض", cls: "bg-red-900/30 text-red-400" },
};

export default function RegistrationsManager() {
  const [regs, setRegs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  function load() {
    setLoading(true);
    api
      .adminGetRegistrations()
      .then((data) => setRegs(data.registrations))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function updateStatus(reg, status) {
    await api.adminUpdateRegistration(reg.id, status);
    load();
  }

  async function remove(reg) {
    if (!confirm(`حذف طلب "${reg.fullName}"؟`)) return;
    await api.adminDeleteRegistration(reg.id);
    load();
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="font-display font-bold text-2xl text-paper mb-5">طلبات التسجيل</h2>

      {error && <p className="text-rust text-sm mb-4">{error}</p>}
      {loading ? (
        <p className="text-chalk/50 text-sm">جارٍ التحميل...</p>
      ) : (
        <div className="flex flex-col gap-3">
          {regs.map((r) => (
            <div key={r.id} className="bg-[#15161a] border border-line rounded-lg p-4 flex flex-wrap items-center gap-4">
              <div className="flex-1 min-w-[180px]">
                <p className="font-bold text-paper">{r.fullName}</p>
                <p className="text-chalk/60 text-sm">
                  {r.age} سنة — {r.country}
                </p>
              </div>
              <a
                href={`https://wa.me/${r.phone.replace(/[^0-9]/g, "")}`}
                target="_blank"
                rel="noreferrer"
                className="text-rust text-sm hover:underline font-mono"
              >
                {r.phone}
              </a>
              <span className={`text-xs font-mono px-2 py-1 rounded ${STATUS_LABELS[r.status]?.cls}`}>
                {STATUS_LABELS[r.status]?.label}
              </span>
              <select
                value={r.status}
                onChange={(e) => updateStatus(r, e.target.value)}
                className="bg-[#191a1b] border border-line rounded-md px-2 py-1 text-sm text-paper"
              >
                {Object.entries(STATUS_LABELS).map(([value, { label }]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </select>
              <button onClick={() => remove(r)} className="text-chalk/50 hover:text-rust text-sm">
                حذف
              </button>
            </div>
          ))}
        </div>
      )}
      {!loading && regs.length === 0 && <p className="text-chalk/50 text-sm">لا توجد طلبات بعد.</p>}
    </div>
  );
}
