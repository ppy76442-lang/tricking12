import React from "react";

/**
 * يستخرج معرّف فيديو يوتيوب من أي صيغة رابط شائعة
 */
function extractYoutubeId(url) {
  const patterns = [
    /youtube\.com\/watch\?v=([^&]+)/,
    /youtu\.be\/([^?]+)/,
    /youtube\.com\/shorts\/([^?]+)/,
    /youtube\.com\/embed\/([^?]+)/,
  ];
  for (const p of patterns) {
    const match = url.match(p);
    if (match) return match[1];
  }
  return null;
}

/**
 * يحول رابط تيك توك إلى رابط embed
 */
function extractTiktokEmbedUrl(url) {
  const match = url.match(/tiktok\.com\/.*\/video\/(\d+)/);
  if (match) return `https://www.tiktok.com/embed/v2/${match[1]}`;
  return null;
}

/**
 * يحول رابط إنستغرام (ريل/بوست) إلى رابط embed
 */
function extractInstagramEmbedUrl(url) {
  const match = url.match(/instagram\.com\/(reel|p)\/([^/?]+)/);
  if (match) return `https://www.instagram.com/${match[1]}/${match[2]}/embed`;
  return null;
}

/**
 * VideoPlayer
 * props:
 *  - platform: "youtube" | "tiktok" | "instagram" | "direct"
 *  - url: رابط الفيديو الأصلي
 *  - orientation: "portrait" | "landscape" — يحدد نسبة العرض/الارتفاع تلقائيًا
 *  - autoPlay: تشغيل تلقائي بدون صوت (متوافق مع سياسات المتصفحات)
 *  - title: نص بديل/عنوان للفيديو
 */
export default function VideoPlayer({ platform, url, orientation = "landscape", autoPlay = true, title = "" }) {
  const aspectClass = orientation === "portrait" ? "aspect-[9/16]" : "aspect-video";
  const wrapperClass = `relative w-full ${aspectClass} bg-black rounded-md overflow-hidden border border-line`;

  if (platform === "youtube") {
    const videoId = extractYoutubeId(url);
    if (!videoId) return <UnsupportedNotice title={title} url={url} />;
    const params = new URLSearchParams({
      autoplay: autoPlay ? "1" : "0",
      mute: autoPlay ? "1" : "0",
      loop: "1",
      playlist: videoId,
      controls: "1",
      playsinline: "1",
      rel: "0",
    });
    return (
      <div className={wrapperClass}>
        <iframe
          className="absolute inset-0 w-full h-full"
          src={`https://www.youtube.com/embed/${videoId}?${params.toString()}`}
          title={title || "فيديو يوتيوب"}
          allow="autoplay; encrypted-media; picture-in-picture"
          allowFullScreen
          loading="lazy"
        />
      </div>
    );
  }

  if (platform === "tiktok") {
    const embedUrl = extractTiktokEmbedUrl(url);
    if (!embedUrl) return <UnsupportedNotice title={title} url={url} />;
    return (
      <div className={`relative w-full aspect-[9/16] bg-black rounded-md overflow-hidden border border-line`}>
        <iframe
          className="absolute inset-0 w-full h-full"
          src={embedUrl}
          title={title || "فيديو تيك توك"}
          allow="autoplay; encrypted-media"
          allowFullScreen
          loading="lazy"
        />
      </div>
    );
  }

  if (platform === "instagram") {
    const embedUrl = extractInstagramEmbedUrl(url);
    if (!embedUrl) return <UnsupportedNotice title={title} url={url} />;
    return (
      <div className={wrapperClass}>
        <iframe
          className="absolute inset-0 w-full h-full"
          src={embedUrl}
          title={title || "فيديو إنستغرام"}
          loading="lazy"
        />
      </div>
    );
  }

  if (platform === "direct") {
    return (
      <div className={wrapperClass}>
        <video
          className="absolute inset-0 w-full h-full object-contain bg-black"
          src={url}
          autoPlay={autoPlay}
          muted={autoPlay}
          loop
          controls
          playsInline
        />
      </div>
    );
  }

  return <UnsupportedNotice title={title} url={url} />;
}

function UnsupportedNotice({ title, url }) {
  return (
    <div className="w-full aspect-video bg-ink border border-line rounded-md flex flex-col items-center justify-center gap-2 p-4 text-center">
      <p className="text-chalk text-sm">تعذّر تشغيل هذا الفيديو مباشرة.</p>
      <a href={url} target="_blank" rel="noreferrer" className="text-rust text-sm underline">
        فتح الفيديو في صفحة جديدة {title ? `— ${title}` : ""}
      </a>
    </div>
  );
}
