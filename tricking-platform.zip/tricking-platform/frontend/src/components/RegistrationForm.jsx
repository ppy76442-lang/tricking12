import React, { useState } from "react";
import { api } from "../api/client.js";

const initialForm = { fullName: "", age: "", country: "", phone: "" };

export default function RegistrationForm({ onClose }) {
  const [form, setForm] = useState(initialForm);
  const [step, setStep] = useState(1); // نموذج مقسم لخطوتين يقلل الإحساس بطول النموذج
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function goNext(e) {
    e.preventDefault();
    if (!form.fullName.trim() || !form.age) {
      setError("أدخل الاسم والعمر للمتابعة.");
      return;
    }
    setError("");
    setStep(2);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.country.trim() || !form.phone.trim()) {
      setError("أدخل الدولة ورقم الهاتف لإكمال الطلب.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const result = await api.submitRegistration(form);
      setSuccess(true);
      // فتح واتساب مباشرة في تبويب جديد لإكمال التواصل فورًا
      window.open(result.whatsappUrl, "_blank");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center px-4">
      <div className="bg-[#15161a] border border-line rounded-lg max-w-md w-full p-6 relative">
        <button
          onClick={onClose}
          className="absolute left-4 top-4 text-chalk/60 hover:text-paper text-xl leading-none"
          aria-label="إغلاق"
        >
          ×
        </button>

        {success ? (
          <div className="text-center py-6">
            <div className="text-4xl mb-3">✅</div>
            <h3 className="font-display font-bold text-xl text-paper mb-2">تم استلام طلبك</h3>
            <p className="text-chalk/80 text-sm mb-4">
              فتحنا لك واتساب لإكمال التواصل المباشر. لو لم يفتح تلقائيًا، تأكد من السماح للنوافذ المنبثقة.
            </p>
            <button
              onClick={onClose}
              className="bg-rust hover:bg-rustdim transition-colors text-white font-bold rounded-md px-6 py-2"
            >
              إغلاق
            </button>
          </div>
        ) : (
          <>
            <div className="flex items-center gap-2 mb-1">
              <span className={`h-1.5 flex-1 rounded ${step >= 1 ? "bg-rust" : "bg-line"}`} />
              <span className={`h-1.5 flex-1 rounded ${step >= 2 ? "bg-rust" : "bg-line"}`} />
            </div>
            <p className="font-mono text-xs text-chalk/60 mb-4">خطوة {step} من 2</p>

            <h3 className="font-display font-bold text-xl text-paper mb-5">
              {step === 1 ? "معلوماتك الأساسية" : "وين نتواصل معك؟"}
            </h3>

            {step === 1 ? (
              <form onSubmit={goNext} className="flex flex-col gap-3">
                <Field
                  label="الاسم الكامل"
                  value={form.fullName}
                  onChange={(v) => update("fullName", v)}
                  placeholder="مثال: محمد أحمد"
                />
                <Field
                  label="العمر"
                  type="number"
                  value={form.age}
                  onChange={(v) => update("age", v)}
                  placeholder="مثال: 22"
                />
                {error && <p className="text-rust text-sm">{error}</p>}
                <button
                  type="submit"
                  className="bg-rust hover:bg-rustdim transition-colors text-white font-bold rounded-md py-3 mt-2"
                >
                  التالي
                </button>
              </form>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col gap-3">
                <Field
                  label="الدولة"
                  value={form.country}
                  onChange={(v) => update("country", v)}
                  placeholder="مثال: اليمن"
                />
                <Field
                  label="رقم الهاتف (مع رمز الدولة)"
                  value={form.phone}
                  onChange={(v) => update("phone", v)}
                  placeholder="مثال: 967xxxxxxxxx"
                />
                {error && <p className="text-rust text-sm">{error}</p>}
                <div className="flex gap-2 mt-2">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="flex-1 border border-line text-chalk rounded-md py-3"
                  >
                    رجوع
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-[2] bg-rust hover:bg-rustdim disabled:opacity-50 transition-colors text-white font-bold rounded-md py-3"
                  >
                    {loading ? "جارٍ الإرسال..." : "إرسال الطلب"}
                  </button>
                </div>
              </form>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function Field({ label, value, onChange, placeholder, type = "text" }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-chalk/80 text-sm">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="bg-[#191a1b] border border-line rounded-md px-3 py-2.5 text-paper focus:outline-none focus:border-rust"
      />
    </label>
  );
}
