import React, { useState } from "react";
import { api, saveAccessKey } from "../api/client.js";

export default function AccessGate({ onUnlocked }) {
  const [keyValue, setKeyValue] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    if (!keyValue.trim()) {
      setError("أدخل مفتاح التصريح أولًا.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const result = await api.verifyKey(keyValue.trim());
      if (result.valid) {
        saveAccessKey(keyValue.trim());
        onUnlocked();
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-ink flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <p className="font-mono text-rust text-xs tracking-widest uppercase mb-3 text-center">
          منصة تعليم التريكنغ
        </p>
        <h1 className="font-display font-extrabold text-2xl text-paper text-center mb-8">
          أدخل مفتاح التصريح
        </h1>

        <form onSubmit={handleSubmit} className="flex flex-col gap-3">
          <input
            type="text"
            inputMode="numeric"
            value={keyValue}
            onChange={(e) => setKeyValue(e.target.value)}
            placeholder="مثال: 500485896"
            className="w-full bg-[#191a1b] border border-line rounded-md px-4 py-3 text-paper text-center font-mono text-lg tracking-widest focus:outline-none focus:border-rust"
            autoFocus
          />

          {error && <p className="text-rust text-sm text-center">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="bg-rust hover:bg-rustdim disabled:opacity-50 transition-colors text-white font-bold rounded-md py-3 mt-2"
          >
            {loading ? "جارٍ التحقق..." : "دخول"}
          </button>
        </form>

        <p className="text-chalk/60 text-xs text-center mt-6">
          لا تملك مفتاح تصريح؟ سجّل اهتمامك بالانضمام من الصفحة الرئيسية بعد المشاهدة.
        </p>
      </div>
    </div>
  );
}
