import React from "react";
import { Navigate } from "react-router-dom";
import { isAdminLoggedIn } from "../api/client.js";

export default function AdminGuard({ children }) {
  if (!isAdminLoggedIn()) {
    return <Navigate to="/admin/login" replace />;
  }
  return children;
}
